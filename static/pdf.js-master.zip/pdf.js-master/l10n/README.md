Most of the files in this folder (except for the `en-US` folder) have been
imported from the Firefox Nightly branch;
please see https://hg.mozilla.org/l10n-central. Some of the files are
licensed under the MPL license. You can obtain a copy of the license at
https://mozilla.org/MPL/2.0.
