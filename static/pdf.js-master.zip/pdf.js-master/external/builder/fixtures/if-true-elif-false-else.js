'use strict';
//#if TRUE
var a;
//#elif FALSE
var b;
//#else
var c;
//#endif
