'use strict';
//#if FALSE
//#error "Some Error"
//#endif
var a;
